import Image from 'next/image';
import Link from 'next/link';
import { Profile } from '@/lib/content';
import { Github, Linkedin } from 'lucide-react';

interface HeroProps {
  profile: Profile;
  summaryHtml: string;
}

export default function Hero({ profile, summaryHtml }: HeroProps) {
  return (
    <section id="about" className="pt-32 pb-24">
      <div className="max-w-5xl mx-auto px-4 flex flex-col md:flex-row items-center gap-12">
        {/* Left photo card */}
        <div className="relative w-64 flex-shrink-0">
          <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-card hover:shadow-cardHover transition-shadow">
            <div className="p-6 flex flex-col items-center">
              <div className="relative w-40 h-40 mb-4">
                <Image
                  src="/headshot.jpg"
                  alt={`${profile.name} headshot`}
                  fill
                  sizes="160px"
                  className="rounded-full object-cover"
                  priority
                />
              </div>
              <h2 className="text-xl font-semibold mb-1">{profile.name}</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">{profile.title}</p>
              {/* Social icons row */}
              <div className="flex gap-4 mt-3">
                {profile.links?.map(({ platform, url }) => {
                  const Icon = platform.toLowerCase().includes('github')
                    ? Github
                    : platform.toLowerCase().includes('linkedin')
                    ? Linkedin
                    : null;
                  return (
                    <a
                      key={platform}
                      href={url}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={platform}
                      className="text-gray-500 dark:text-gray-400 hover:text-brand dark:hover:text-brand transition-colors"
                    >
                      {Icon ? (
                        <Icon size={20} />
                      ) : (
                        <span className="text-sm font-medium uppercase">{platform[0]}</span>
                      )}
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right content */}
        <div className="flex-1">
          <h1 className="text-5xl font-bold mb-6 leading-tight">
            Hello
          </h1>
          <div
            className="prose prose-neutral dark:prose-invert max-w-none mb-6"
            dangerouslySetInnerHTML={{ __html: summaryHtml }}
          />
          <div className="flex gap-4 flex-wrap">
            <a
              href="/cv.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-brand text-white px-6 py-2 rounded-full font-medium hover:bg-brand-dark focus:outline-none focus:ring-2 focus:ring-brand"
            >
              Download CV
            </a>
            <a
              href="#projects"
              className="inline-block bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-gray-200 px-6 py-2 rounded-full font-medium hover:bg-gray-300 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-brand"
            >
              Projects
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}