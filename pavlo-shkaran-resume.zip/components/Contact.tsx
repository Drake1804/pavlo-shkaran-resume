import { loadProfile } from '@/lib/content';
import { Github, Linkedin, Mail } from 'lucide-react';

export default async function ContactSection() {
  const profile = await loadProfile();
  return (
    <footer id="contact" className="py-16 bg-gray-100 dark:bg-gray-900 mt-24">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-6">Get in Touch</h2>
        <p className="mb-4 text-gray-700 dark:text-gray-300">Feel free to reach out if you'd like to collaborate or just say hello.</p>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2">
            {profile.email && (
              <p className="flex items-center gap-2">
                <Mail size={16} className="text-brand" />
                <a href={`mailto:${profile.email}`} className="hover:underline">
                  {profile.email}
                </a>
              </p>
            )}
            {profile.location && (
              <p className="text-gray-600 dark:text-gray-400">{profile.location}</p>
            )}
          </div>
          <div className="flex gap-4">
            {profile.links?.map(({ platform, url }) => {
              const Icon = platform.toLowerCase().includes('github')
                ? Github
                : platform.toLowerCase().includes('linkedin')
                ? Linkedin
                : null;
              return (
                <a
                  key={platform}
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 dark:text-gray-400 hover:text-brand dark:hover:text-brand transition-colors"
                >
                  {Icon ? <Icon size={20} /> : <span className="uppercase text-sm">{platform[0]}</span>}
                </a>
              );
            })}
          </div>
        </div>
        <p className="mt-8 text-sm text-gray-500 dark:text-gray-500">© {new Date().getFullYear()} {profile.name}. All rights reserved.</p>
      </div>
    </footer>
  );
}