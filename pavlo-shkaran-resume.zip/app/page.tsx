import Header from '@/components/Header';
import Hero from '@/components/Hero';
import SkillChips from '@/components/SkillChips';
import Timeline from '@/components/Timeline';
import ProjectsSection from '@/components/Projects';
import ContactSection from '@/components/Contact';
import {
  loadProfile,
  loadSummary,
  loadSkills,
  loadExperience,
} from '@/lib/content';

export default async function Page() {
  const profile = await loadProfile();
  const summaryHtml = await loadSummary();
  const skills = await loadSkills();
  const experience = await loadExperience();
  return (
    <>
      <Header />
      <main className="">
        <Hero profile={profile} summaryHtml={summaryHtml} />
        <SkillChips skills={skills} />
        <Timeline items={experience} />
        <ProjectsSection />
        <ContactSection />
      </main>
    </>
  );
}