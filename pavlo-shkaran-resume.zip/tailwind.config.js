/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
    './content/**/*.{md}'
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#3457D5', // royal blue accent
          light: '#5677E6',
          dark: '#1E3A8A'
        },
        background: {
          light: '#FAFAFA',
          dark: '#121212'
        },
        text: {
          light: '#1F2937', // gray-800
          dark: '#E5E7EB'
        }
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif']
      },
      boxShadow: {
        card: '0 4px 12px rgba(0, 0, 0, 0.05)',
        cardHover: '0 6px 20px rgba(0, 0, 0, 0.08)'
      }
    }
  },
  plugins: []
};