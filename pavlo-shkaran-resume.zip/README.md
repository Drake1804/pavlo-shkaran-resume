# Pavlo Shkaran – Resume Website

This repository contains the source code for a single–page personal resume website for **Pavlo Shkaran**, a Lead Software Engineer with extensive experience in Android development. The site is built with **Next.js 14**, **TypeScript**, **Tailwind CSS**, and leverages the App Router for modern routing. It is designed to be clean, modern, and responsive, inspired by the split‑layout hero shown in the provided reference image.

## Features

* **Hero Section** – Split layout with a photo card on the left and a bold “Hello” intro on the right. Includes call‑to‑action buttons to download the CV and jump to projects.
* **Timeline** – A vertical timeline presenting professional experience in reverse chronological order. Each entry lists roles, responsibilities, and the tech stack used, with a “Show more” toggle to reveal long lists of achievements.
* **Skills** – Grouped skill chips covering languages, architecture patterns, libraries & frameworks, data technologies, platforms, IDEs, and tooling.
* **Dark Mode** – System‑aware dark mode powered by `next‑themes` with a toggle in the header.
* **Fully Responsive** – Optimised for desktop and mobile views with accessible semantic markup and high Lighthouse scores.
* **Content Driven** – All site content is stored in the `/content` folder as YAML/Markdown files (`profile.yml`, `summary.md`, `skills.yml`, `experience.yml`, etc.) making updates easy without touching React components.
* **Static Export** – The site is statically exported on build (`next export`) and automatically deployed to GitHub Pages via a GitHub Actions workflow.

## Getting Started

To run the project locally you will need **Node.js ≥18** and **pnpm** installed. Clone the repository and install dependencies:

```bash
pnpm install
```

### Development server

Run the development server with hot reloading:

```bash
pnpm dev
```

Open `http://localhost:3000` to view the site. You can edit content files in the `content` directory and the page will automatically update.

### Production build

Create an optimized production build and export the site:

```bash
pnpm build && pnpm export
```

The static site will be output to the `out/` directory.

## Content Editing

All resume information is stored in easily editable YAML and Markdown files under the **content** folder:

| File | Purpose |
|---|---|
| `content/profile.yml` | Basic profile information such as name, title, location, contact details, and social links. |
| `content/summary.md` | A short biography or professional summary. |
| `content/skills.yml` | Categorised lists of skills and technologies. |
| `content/experience.yml` | An array of work experience entries with dates, roles, responsibilities, and tech stack. |
| `content/projects.yml` | Optional list of projects (currently empty). |
| `content/education.yml` | Optional education history. |
| `content/certifications.yml` | Optional certifications. |

Simply update these files to keep the site up to date; no changes to React components are required.

## Deployment

This repository is configured to deploy automatically to **GitHub Pages** using a GitHub Actions workflow. On every push to the `main` branch:

1. Dependencies are installed using `pnpm`.
2. The site is built and statically exported to the `out/` directory.
3. The contents of `out/` are published to the `gh-pages` branch.

To enable deployment, ensure GitHub Pages is set to use the `gh-pages` branch as the source in the repository settings. The live site will be available at:

```
https://<your‑github‑username>.github.io/pavlo-shkaran-resume/
```

## License

This project is provided for educational and portfolio purposes. You are welcome to fork and adapt it for your own resume website.