import fs from 'fs/promises';
import path from 'path';
import matter from 'gray-matter';
import yaml from 'yaml';
import { remark } from 'remark';
import html from 'remark-html';

export interface Profile {
  name: string;
  title: string;
  location: string;
  email?: string;
  phone?: string;
  links?: { platform: string; url: string }[];
}

export interface SkillGroups {
  [category: string]: string[];
}

export interface ExperienceItem {
  company: string;
  role: string;
  start: string;
  end?: string;
  location?: string;
  customer?: string;
  customer_description?: string;
  project_description?: string;
  summary?: string;
  bullets?: string[];
  stack?: string[];
}

/** Read a file relative to the project root */
async function readFile(relPath: string): Promise<string> {
  const fullPath = path.join(process.cwd(), relPath);
  return await fs.readFile(fullPath, 'utf8');
}

export async function loadProfile(): Promise<Profile> {
  const raw = await readFile('content/profile.yml');
  return yaml.parse(raw);
}

export async function loadSummary(): Promise<string> {
  const raw = await readFile('content/summary.md');
  const parsed = matter(raw);
  // Cast the html plugin to `any` to avoid TypeScript type incompatibilities
  // between the remark processor and this plugin. Without this cast the
  // signature of the plugin doesn't match what remark expects and the build
  // fails during type checking.
  const processed = await remark().use(html as any).process(parsed.content);
  return processed.toString();
}

export async function loadSkills(): Promise<SkillGroups> {
  const raw = await readFile('content/skills.yml');
  return yaml.parse(raw);
}

export async function loadExperience(): Promise<ExperienceItem[]> {
  const raw = await readFile('content/experience.yml');
  const data = yaml.parse(raw);
  // Ensure items sorted by start date descending
  return (data as ExperienceItem[]).sort((a, b) => {
    return (b.start || '').localeCompare(a.start || '');
  });
}

export async function loadProjects(): Promise<any[]> {
  try {
    const raw = await readFile('content/projects.yml');
    const data = yaml.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function loadEducation(): Promise<any[]> {
  try {
    const raw = await readFile('content/education.yml');
    const data = yaml.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function loadCertifications(): Promise<any[]> {
  try {
    const raw = await readFile('content/certifications.yml');
    const data = yaml.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}