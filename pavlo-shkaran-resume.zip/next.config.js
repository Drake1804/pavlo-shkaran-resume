/**
 * @type {import('next').NextConfig}
 */
const repo = 'pavlo-shkaran-resume';
const isProd = process.env.NODE_ENV === 'production';

/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  },
  // Enable static export with Next.js 14
  output: 'export',
  images: {
    // Disable image optimization during export; Next.js will simply copy files from /public
    unoptimized: true
  },
  trailingSlash: true,
  /**
   * When deploying to GitHub Pages the site is served from a sub-path equal to the repository name.
   * Set the basePath and assetPrefix accordingly only in production.
   */
  basePath: isProd ? `/${repo}` : '',
  assetPrefix: isProd ? `/${repo}/` : ''
};

module.exports = nextConfig;