import './globals.css';
import { ReactNode } from 'react';
import { ThemeProvider } from 'next-themes';
import { Inter } from 'next/font/google';

// Load the Inter font with latin subset; use 'display' swap for performance
const inter = Inter({ subsets: ['latin'], display: 'swap' });

export const metadata = {
  title: 'Pavlo Shkaran – Lead Software Engineer',
  description: 'Personal resume website for Pavlo Shkaran, Lead Software Engineer',
  keywords: ['Pavlo Shkaran', 'resume', 'Lead Software Engineer', 'Android'],
  openGraph: {
    title: 'Pavlo Shkaran – Lead Software Engineer',
    images: ['/og.png']
  }
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}