/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  },
  // Enable static export with Next.js 14
  output: 'export',
  images: {
    // Disable image optimization during export; Next.js will simply copy files from /public
    unoptimized: true
  },
  trailingSlash: true
};

module.exports = nextConfig;