import { SkillGroups } from '@/lib/content';

interface SkillChipsProps {
  skills: SkillGroups;
}

const categoryLabels: Record<string, string> = {
  languages: 'Languages',
  architecture: 'Architecture',
  libraries_frameworks: 'Libraries & Frameworks',
  data: 'Data',
  platforms: 'Platforms',
  ide: 'IDEs',
  solution_tools: 'Solutions & Tools'
};

export default function SkillChips({ skills }: SkillChipsProps) {
  return (
    <section id="skills" className="py-16">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Skills</h2>
        <div className="space-y-6">
          {Object.keys(skills).map((key) => {
            const items = skills[key];
            if (!Array.isArray(items) || items.length === 0) return null;
            const label = categoryLabels[key] || key;
            return (
              <div key={key} className="">
                <h3 className="text-xl font-semibold mb-2 text-brand">{label}</h3>
                <div className="flex flex-wrap gap-2">
                  {items.map((item) => (
                    <span
                      key={item}
                      className="inline-block px-3 py-1 rounded-full bg-gray-200 dark:bg-gray-800 text-sm text-gray-800 dark:text-gray-200"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}