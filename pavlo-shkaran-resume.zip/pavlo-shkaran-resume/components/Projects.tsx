import { loadProjects } from '@/lib/content';

export default async function ProjectsSection() {
  const projects = await loadProjects();
  if (!projects || projects.length === 0) {
    return null;
  }
  return (
    <section id="projects" className="py-16">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Projects</h2>
        <p className="text-gray-600 dark:text-gray-400">Projects will be added in the future.</p>
      </div>
    </section>
  );
}