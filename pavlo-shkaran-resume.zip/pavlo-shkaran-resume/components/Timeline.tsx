"use client";

import { useState } from 'react';
import { ExperienceItem } from '@/lib/content';
import { motion } from 'framer-motion';

interface TimelineProps {
  items: ExperienceItem[];
}

// Helper to format dates as "Mon‑YYYY" or just year when month not provided
function formatRange(start?: string, end?: string): string {
  const fmt = (date?: string) => {
    if (!date) return 'Present';
    const [y, m] = date.split('-');
    if (m) {
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const idx = parseInt(m, 10) - 1;
      return `${monthNames[idx]} ${y}`;
    }
    return y;
  };
  return `${fmt(start)} – ${fmt(end)}`;
}

export default function Timeline({ items }: TimelineProps) {
  return (
    <section id="experience" className="py-16">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Experience</h2>
        <div className="timeline space-y-12">
          {items.map((item, idx) => (
            <TimelineItem key={idx} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TimelineItem({ item }: { item: ExperienceItem }) {
  const [expanded, setExpanded] = useState(false);
  const showAll = expanded || (item.bullets?.length ?? 0) <= 4;
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.4, delay: 0.05 }}
      className="relative pl-8"
    >
      {/* Dot */}
      <span className="absolute left-0 top-2 w-3 h-3 rounded-full bg-brand"></span>
      <div className="">
        <div className="flex flex-col md:flex-row md:items-baseline md:justify-between">
          <div>
            <h3 className="text-xl font-semibold">
              {item.role}
              <span className="text-brand font-normal"> @ {item.company}</span>
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {formatRange(item.start, item.end)}
              {item.location ? ` • ${item.location}` : ''}
            </p>
          </div>
        </div>
        {item.summary && <p className="mt-2 text-gray-700 dark:text-gray-300">{item.summary}</p>}
        {item.bullets && item.bullets.length > 0 && (
          <ul className="list-disc pl-5 mt-3 space-y-1 text-gray-700 dark:text-gray-300 text-sm">
            {(showAll ? item.bullets : item.bullets.slice(0, 4)).map((b, i) => (
              <li key={i}>{b}</li>
            ))}
            {!showAll && (
              <li key="more">
                <button
                  onClick={() => setExpanded(true)}
                  className="text-brand underline underline-offset-2"
                >
                  Show more
                </button>
              </li>
            )}
          </ul>
        )}
        {item.stack && item.stack.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {item.stack.map((tech) => (
              <span
                key={tech}
                className="inline-block px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-800 text-xs text-gray-800 dark:text-gray-200"
              >
                {tech}
              </span>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}